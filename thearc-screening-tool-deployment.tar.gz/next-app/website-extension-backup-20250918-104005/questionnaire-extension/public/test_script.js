console.log("Script loaded"); function nextSection() { console.log("nextSection called"); }
