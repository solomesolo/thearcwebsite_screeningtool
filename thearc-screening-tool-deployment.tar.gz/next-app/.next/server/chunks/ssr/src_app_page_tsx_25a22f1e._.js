module.exports = {

"[project]/src/app/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>Home
});
"use client";
function Home() {
    return null;
}
}),

};

//# sourceMappingURL=src_app_page_tsx_25a22f1e._.js.map