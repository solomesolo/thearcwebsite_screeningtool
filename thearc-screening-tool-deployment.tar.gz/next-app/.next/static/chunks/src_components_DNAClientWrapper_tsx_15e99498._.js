(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/DNAClientWrapper.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_components_39109394._.js",
  "static/chunks/src_components_DNAClientWrapper_tsx_a5b01ee0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/DNAClientWrapper.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
}]);