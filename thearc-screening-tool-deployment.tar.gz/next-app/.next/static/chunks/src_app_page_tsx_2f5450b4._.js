(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_29a2f681._.js",
  "static/chunks/node_modules_6a262635._.js"
],
    source: "dynamic"
});
