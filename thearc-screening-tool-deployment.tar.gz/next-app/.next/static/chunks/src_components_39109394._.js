(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/components/DNAParticles.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>DNAParticles
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const NUM_PARTICLES = 180;
const AMPLITUDE_RATIO = 0.22;
const SPEED = 0.0005;
const COLOR = "#d946ef";
function DNAParticles() {
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [dimensions, setDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        width: 1920,
        height: 1080
    });
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DNAParticles.useEffect": ()=>{
            setMounted(true);
            function handleResize() {
                setDimensions({
                    width: window.innerWidth,
                    height: window.innerHeight
                });
            }
            handleResize();
            window.addEventListener("resize", handleResize);
            return ({
                "DNAParticles.useEffect": ()=>window.removeEventListener("resize", handleResize)
            })["DNAParticles.useEffect"];
        }
    }["DNAParticles.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DNAParticles.useEffect": ()=>{
            if (!mounted) return;
            let frame;
            const svg = ref.current;
            if (!svg) return;
            const particles = Array.from(svg.querySelectorAll("circle"));
            const width = dimensions.width;
            const height = dimensions.height;
            const amplitude = height * AMPLITUDE_RATIO;
            const yOffset = height / 2;
            const xStart = 0;
            const xEnd = width;
            function animate(time) {
                for(let i = 0; i < NUM_PARTICLES; i++){
                    const t = i / NUM_PARTICLES * Math.PI * 4 + time * SPEED;
                    const x = xStart + i / NUM_PARTICLES * (xEnd - xStart);
                    const y = yOffset + Math.sin(t) * amplitude;
                    if (particles[i]) {
                        particles[i].setAttribute("cx", x.toString());
                        particles[i].setAttribute("cy", y.toString());
                    }
                    const y2 = yOffset + Math.cos(t) * amplitude * 0.95;
                    if (particles[i + NUM_PARTICLES]) {
                        particles[i + NUM_PARTICLES].setAttribute("cx", x.toString());
                        particles[i + NUM_PARTICLES].setAttribute("cy", y2.toString());
                    }
                }
                frame = requestAnimationFrame(animate);
            }
            frame = requestAnimationFrame(animate);
            return ({
                "DNAParticles.useEffect": ()=>cancelAnimationFrame(frame)
            })["DNAParticles.useEffect"];
        }
    }["DNAParticles.useEffect"], [
        dimensions,
        mounted
    ]);
    if (!mounted) return null;
    const width = dimensions.width;
    const height = dimensions.height;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        ref: ref,
        width: width,
        height: height,
        style: {
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            zIndex: 0,
            pointerEvents: "none",
            opacity: 0.45,
            background: "transparent",
            transition: "width 0.2s, height 0.2s",
            display: "block",
            objectFit: "cover"
        },
        viewBox: "0 0 ".concat(width, " ").concat(height),
        preserveAspectRatio: "none",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("defs", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("clipPath", {
                    id: "dna-clip",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                        x: "0",
                        y: "0",
                        width: width,
                        height: height
                    }, void 0, false, {
                        fileName: "[project]/src/components/DNAParticles.tsx",
                        lineNumber: 87,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/DNAParticles.tsx",
                    lineNumber: 86,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/DNAParticles.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("g", {
                clipPath: "url(#dna-clip)",
                children: Array.from({
                    length: NUM_PARTICLES * 2
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        r: "3.5",
                        fill: COLOR,
                        opacity: "0.7"
                    }, i, false, {
                        fileName: "[project]/src/components/DNAParticles.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/src/components/DNAParticles.tsx",
                lineNumber: 90,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/DNAParticles.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_s(DNAParticles, "CdM3LLlkwJWgUXsxA7eYOeuxe/M=");
_c = DNAParticles;
var _c;
__turbopack_context__.k.register(_c, "DNAParticles");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/DNAClientWrapper.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>DNAClientWrapper
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DNAParticles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/DNAParticles.tsx [app-client] (ecmascript)");
"use client";
;
;
function DNAClientWrapper() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$DNAParticles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/components/DNAClientWrapper.tsx",
        lineNumber: 5,
        columnNumber: 10
    }, this);
}
_c = DNAClientWrapper;
var _c;
__turbopack_context__.k.register(_c, "DNAClientWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/DNAClientWrapper.tsx [app-client] (ecmascript, next/dynamic entry)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/components/DNAClientWrapper.tsx [app-client] (ecmascript)"));
}),
}]);

//# sourceMappingURL=src_components_39109394._.js.map