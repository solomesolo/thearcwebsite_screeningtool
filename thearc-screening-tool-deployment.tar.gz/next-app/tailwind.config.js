module.exports = {
  theme: {
    extend: {
      fontFamily: {
        montserrat: ['var(--font-montserrat)', 'ui-sans-serif', 'system-ui'],
      },
    },
  },
} 