"use client";
import DNAParticles from "./DNAParticles";

export default function DNAClientWrapper() {
  return <DNAParticles />;
} 